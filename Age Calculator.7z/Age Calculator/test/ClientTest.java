import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.psl.exceptions.InvalidDateFormatException;
import com.psl.main.Client;


public class ClientTest {
	Client client;
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		client=new Client(); 
	}

	@After
	public void tearDown() throws Exception {
//		client=null;
	}

	@Test(expected=InvalidDateFormatException.class)
	public void testMain() {
//		fail("Not yet implemented");
		client.findAge("110/1995");
		
	}

}
