package com.psl.main;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.psl.exceptions.InvalidDateFormatException;

public class Client {
	public static void main(String[] args) {
		Client client=new Client();
		int age = 0;
		age = findAge("110/1995");
		System.out.println(age);
	}

	public static int findAge(String string) {
		int age=0;
		boolean flag=false;
		DateFormat df=new SimpleDateFormat("dd/MM/yyyy");
		Date bdate = new Date();
		Calendar today=Calendar.getInstance();
		Calendar bday=Calendar.getInstance();
		
		try {
			bdate = df.parse(string);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
//			flag=true;
			try {
				throw new InvalidDateFormatException("wrong date format please enter correct date ...");
			} catch (InvalidDateFormatException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
//		if(flag) {
//			
//		}
			
		bday.setTime(bdate);
		
		if(today.before(bday)){
//			age=0;
			return 0;
		}
		else{
			int year1=today.get(Calendar.YEAR);
			int year2=bday.get(Calendar.YEAR);
			age=year1-year2;
			int month1=today.get(Calendar.MONTH);
			int month2=bday.get(Calendar.MONTH);
			if(month1<month2){
				age--;
			}
			if(month1==month2){
				age--;
				int day1=today.get(Calendar.DAY_OF_MONTH);
				int day2=bday.get(Calendar.DAY_OF_MONTH);
				if(day1==day2){
					age++;
					System.out.println("Turning "+(age)+"years old.");
					System.out.println("happy birthday !!!");
				}
			}
		}
		return age;
	}
}
