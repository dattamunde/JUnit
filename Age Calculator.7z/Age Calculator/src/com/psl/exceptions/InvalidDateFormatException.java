package com.psl.exceptions;

public class InvalidDateFormatException extends Exception {
	private static final long serialVersionUID = -5374767846723765843L;
	
	public InvalidDateFormatException() {
	}

	public InvalidDateFormatException(String string) {
		super(string);
	}

}
