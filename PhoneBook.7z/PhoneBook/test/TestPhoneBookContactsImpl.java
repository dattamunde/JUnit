import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.psl.exception.NoDataFoundException;
import com.psl.util.PhoneBookContacts;
import com.psl.util.PhoneBookContactsImpl;


public class TestPhoneBookContactsImpl {

	@Before
	public void setUp() {
		PhoneBookContactsImpl contact=new PhoneBookContactsImpl();
	}
	@Test
	public void testAddContact() {
		List<String> contacts=new ArrayList<String>();
		contacts.add("3342451234");
		contacts.add("3243434234");
		
		PhoneBookContacts contact=new PhoneBookContactsImpl();
		
		contact.addContact("Seema", contacts);
		
		contacts=new ArrayList<String>();
		contacts.add("2334234");
		contacts.add("7776654");
		contact.addContact("Reema",contacts);
	}

	@Test
	public void testGetContactMap() {
		PhoneBookContacts contact=new PhoneBookContactsImpl();
		System.out.println("Entire Map :" + contact.getContactMap());
	}

	@Test (expected = NoDataFoundException.class)
	public void testSearchContact() {
		PhoneBookContacts contact=new PhoneBookContactsImpl();
		try {
			System.out.println(" Seema's contact :" + contact.searchContact("Seema") );
			System.out.println(" Ria's contact (not available) :" + contact.searchContact("Ria") );
		} catch (NoDataFoundException e) {
			System.out.println(e.getMessage());
		}
	}

}
